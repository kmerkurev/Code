function uhat = ft(f,V)
M = size(V,2);
uhat = zeros(M,1);
for n = 1:M
    uhat(n) = sum(f.*V(:,n));
end