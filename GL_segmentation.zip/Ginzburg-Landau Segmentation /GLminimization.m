% -------------------------------------------------------------------------
% yana landa
% yanalanda@gmail.com
%
% implementation of Ginzburg-Landau energy minimization based on
% Bertozzi-Flenner paper
% fidelity term utilizes the learning data
% 
% Input:
% uo: is -1 everywhere but a few pixels on the object of interest, where it
% is set to 1
% Lambda, Phi: corresponding eigenvalues/vectors of graph-Laplacian
% lam: indicator function in front of the fidelity term: 0 everywhere but a
% few pixels on the object of interest, where it is set to 1
% c: parameter in the convex splitting
% c1: parameter in front of the fidelity term
% eps: interface width parameter in the LG energy
% dt: time step
% iterNum: number of iterations in energy minimization
% 
% Output:
% u: has values close to +- 1
% -------------------------------------------------------------------------

function u = GLminimization(uo, Lambda, Phi, lam, c, c1, eps, dt, iterNum)
u = uo;
L = size(Phi,2);

a = ft(u, Phi);
b = ft(u.^3, Phi);
d = zeros(L,1);
Denom = 1 + dt*(eps*Lambda+c);

% main iteration
for n = 1:iterNum
    disp(n);
    a = ((1 + dt/eps + c*dt)*a - dt*b/eps - dt*d)./Denom;
    u = bt(a, Phi);
    b = ft(u.^3, Phi);
    d = c1*ft(lam.*(u-uo),Phi);
end
