function visIm(im, uo, N1, N2)
U = im;
k = 1;
for i = 1:N1
    for j = 1:N2
        if uo(k) < 0
            U(i,j,:) = 0;
        end
        k = k+1;
    end
end

image(uint8(U));
axis equal tight