function u = bt(uhat,V)
N = size(V,1);
u = zeros(N,1);
for i = 1:N
    u(i) = sum(uhat.*V(i,:)');
end