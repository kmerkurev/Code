% -------------------------------------------------------------------------
% This code was written by Yana Landa
%
%
% simple semi-supervised learning: choose pixels belonging to an object
% then segment the entire object
% -------------------------------------------------------------------------

clear all

%%%%%%%%%%%%%%%% READ THE IMAGE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
im = double(imread('original.png','png'));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% image dimensions
N1 = size(im,1);
N2 = size(im,2);
N = N1*N2;

%%%%%%%%%%%%%%%%%%  PARAMETERS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
L = 200;        % number of eigenvalues/vectors to be computed by Nystrom
sigma = 22;     % parameter in distance
c = 11;         % parameter in the convex splitting
eps = 100;      % interface width parameter in the LG energy
c1 = 100;       % parameter in front of the fidelity term
dt = 0.001;     % time step
iterNum = 400;  % number of iterations in energy minimization
simWindowSize = 2; % the patch size is (2*simWindowSize+1)^2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% using nonlocal means
fv = featureVec(im, simWindowSize);     % contains neighborhood pixels within the corresponding patch
kernel = make_kernel(simWindowSize);

% Note: this specific implementation of Nystrom depends on the form of the
% feature vector
[Phi, Lambda] = nystrom_color(fv, kernel, L, sigma); % Nystrom extension

% ---------------
% GL-minimization
% ---------------

%%%%%%%%%%%% INCLUDE THE LABELED INFORMATION HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% original labels on the data
uo1 = -1*ones(N1,N2);
uo1(80:90,100:110) = 1;

% parameter in front of the fidelity term
lambda1 = zeros(N1,N2);
lambda1(80:90,100:110) = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% convert to 1d arrays
uo = zeros(N,1);
lam = zeros(N,1);
k = 1;
for i = 1:N1
    for j = 1:N2
        uo(k) = uo1(i,j);
        lam(k) = lambda1(i,j);
        k = k+1;
    end
end



u = GLminimization(uo, Lambda, Phi, lam, c, c1, eps, dt, iterNum);

% ------------------------------
% visualize segmentation results
% ------------------------------

% original image
figure(1); clf
image(uint8(im));
axis equal tight

% result of the segmentation
figure(3); clf
visIm(im, u, N1, N2);

% patch used for learning
figure(4); clf
visIm(im, uo, N1, N2);




